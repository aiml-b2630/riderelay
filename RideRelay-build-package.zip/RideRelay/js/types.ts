export interface User {
  id: string;
  name: string;
  email: string;
  isVerified: boolean;
  rating: number;
  totalRides: number;
  gender: 'Female' | 'Male' | 'Other';
}

export interface Ride {
  id: string;
  driverName: string;
  driverEmail: string;
  driverRating: number;
  driverGender: 'Female' | 'Male' | 'Other';
  vehicleType: 'Car' | 'Two-Wheeler';
  vehicleModel: string;
  originNeighborhood: string;
  destinationGate: 'North Gate' | 'Canteen Circle' | 'Main Entrance' | 'South Gate';
  departureTime: string;
  availableSeats: number;
  totalSeats: number;
  fuelSplitPerSeat: number;
  isWomenOnly: boolean;
  distanceKm: number;
  vehicleMileageKmpl: number;
  pickupLandmark: string;
  verifiedEmail: boolean;
}

export interface BookingRequest {
  rideId: string;
  passengerName: string;
  passengerEmail: string;
  seatsBooked: number;
  totalCost: number;
  timestamp: string;
}

export interface DigitalRidePass {
  passId: string;
  rideId: string;
  passengerName: string;
  driverName: string;
  origin: string;
  destination: string;
  departureTime: string;
  vehicleModel: string;
  seatsBooked: number;
  totalAmountDue: number;
  upiId: string;
  pickupLandmark: string;
}
