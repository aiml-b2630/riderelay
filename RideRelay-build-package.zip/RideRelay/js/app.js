/**
 * RideRelay - Campus Carpool Application
 * Dynamic TypeScript/JavaScript Frontend Engine (Modules 3–4)
 */

document.addEventListener('DOMContentLoaded', () => {
  // Application State
  let rides = [];
  let filteredRides = [];
  let currentUser = {
    name: 'Verified Student',
    email: 'alex.student@campus.edu',
    isVerified: true
  };

  // DOM Elements
  const ridesContainer = document.getElementById('ridesContainer');
  const ridesCountEl = document.getElementById('ridesCount');
  const searchInput = document.getElementById('searchInput');
  const originFilter = document.getElementById('originFilter');
  const destinationFilter = document.getElementById('destinationFilter');
  const vehicleFilter = document.getElementById('vehicleFilter');
  const womenOnlyToggle = document.getElementById('womenOnlyToggle');

  // Modals
  const offerRideModal = document.getElementById('offerRideModal');
  const bookRideModal = document.getElementById('bookRideModal');
  const ridePassModal = document.getElementById('ridePassModal');
  
  const btnOfferRide = document.getElementById('btnOfferRide');
  const closeOfferModal = document.getElementById('closeOfferModal');
  const closeBookModal = document.getElementById('closeBookModal');
  const closePassModal = document.getElementById('closePassModal');

  // Offer Ride Form & Calculator
  const offerRideForm = document.getElementById('offerRideForm');
  const calcDistance = document.getElementById('calcDistance');
  const calcMileage = document.getElementById('calcMileage');
  const calcFuelPrice = document.getElementById('calcFuelPrice');
  const calcSeats = document.getElementById('calcSeats');
  const calculatedCostVal = document.getElementById('calculatedCostVal');

  // Booking Form
  const bookingForm = document.getElementById('bookingForm');
  const bookRideIdInput = document.getElementById('bookRideIdInput');
  const bookSeatsSelect = document.getElementById('bookSeatsSelect');
  const bookingCostSummary = document.getElementById('bookingCostSummary');

  // Initial Fetch API execution to load typed ride dataset
  async function fetchRides() {
    try {
      // Fetch data/rides.json
      const response = await fetch('./data/rides.json');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      
      // Load saved rides from localStorage if any
      const savedLocalRides = JSON.parse(localStorage.getItem('rideRelay_custom_rides') || '[]');
      rides = [...data, ...savedLocalRides];
      filteredRides = [...rides];
      
      renderRides(filteredRides);
      populateFilterOptions();
    } catch (err) {
      console.warn('Fetch fallback to inline dataset if static file serving:', err);
      // Fallback sample data if opened directly without web server
      rides = getFallbackRides();
      filteredRides = [...rides];
      renderRides(filteredRides);
      populateFilterOptions();
    }
  }

  // Populate dynamic dropdown options from data
  function populateFilterOptions() {
    const origins = setToStringArray(rides.map(r => r.originNeighborhood));
    originFilter.innerHTML = '<option value="">All Neighborhoods</option>' + 
      origins.map(o => `<option value="${o}">${o}</option>`).join('');
  }

  function setToStringArray(arr) {
    return Array.from(new Set(arr)).sort();
  }

  // Render Ride Cards in Flexbox Grid
  function renderRides(rideList) {
    ridesCountEl.textContent = `Showing ${rideList.length} active ride${rideList.length === 1 ? '' : 's'}`;
    
    if (rideList.length === 0) {
      ridesContainer.innerHTML = `
        <div style="width: 100%; text-align: center; padding: 3rem; background: #fff; border-radius: 12px; border: 1px solid #e2e8f0;">
          <h3 style="color: #64748b; font-weight: 600;">No rides matching your criteria</h3>
          <p style="color: #94a3b8; font-size: 0.9rem; margin-top: 0.5rem;">Try adjusting your search filters or offer a new carpool ride!</p>
        </div>
      `;
      return;
    }

    ridesContainer.innerHTML = rideList.map(ride => {
      const isWomenOnly = ride.isWomenOnly;
      const isFullyBooked = ride.availableSeats <= 0;
      
      return `
        <div class="ride-card ${isWomenOnly ? 'women-only-card' : ''}">
          <div class="card-header">
            <div class="driver-info">
              <div class="driver-avatar">${ride.driverName.charAt(0)}</div>
              <div class="driver-details">
                <div class="driver-name">
                  ${ride.driverName}
                  ${ride.verifiedEmail ? '<span class="verified-icon" title="Verified Campus Email">✓</span>' : ''}
                </div>
                <div class="driver-email">${ride.driverEmail}</div>
              </div>
            </div>
            <div class="rating-badge">★ ${ride.driverRating.toFixed(1)}</div>
          </div>

          <div class="card-route">
            <div class="route-node">
              <span class="route-dot origin"></span>
              <strong>${ride.originNeighborhood}</strong>
            </div>
            <div class="route-line"></div>
            <div class="route-node">
              <span class="route-dot destination"></span>
              <strong>${ride.destinationGate}</strong>
            </div>
          </div>

          <div class="tag-badges">
            <span class="badge ${ride.vehicleType === 'Car' ? 'badge-car' : 'badge-bike'}">
              ${ride.vehicleType === 'Car' ? '🚗 Car' : '🏍️ Two-Wheeler'} (${ride.vehicleModel})
            </span>
            ${isWomenOnly ? '<span class="badge badge-women">👩 Women-Only</span>' : ''}
          </div>

          <div class="card-details-grid">
            <div class="detail-item">
              <span class="detail-label">Departure</span>
              <span class="detail-val">⏰ ${ride.departureTime}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Seats Left</span>
              <span class="detail-val" style="color: ${isFullyBooked ? '#ef4444' : '#10b981'};">
                ${ride.availableSeats} / ${ride.totalSeats}
              </span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Fuel Split</span>
              <span class="cost-tag">₹${ride.fuelSplitPerSeat}</span>
            </div>
          </div>

          <div class="card-actions">
            <button 
              class="btn-book" 
              onclick="openBookingModal('${ride.id}')"
              ${isFullyBooked ? 'disabled' : ''}
            >
              ${isFullyBooked ? 'Fully Booked' : 'Book Seat'}
            </button>
          </div>
        </div>
      `;
    }).join('');
  }

  // Real-time Search & Filter Engine
  function applyFilters() {
    const searchTerm = searchInput.value.toLowerCase().trim();
    const originVal = originFilter.value;
    const destVal = destinationFilter.value;
    const vehicleVal = vehicleFilter.value;
    const womenOnlyVal = womenOnlyToggle.checked;

    filteredRides = rides.filter(ride => {
      const matchesSearch = ride.originNeighborhood.toLowerCase().includes(searchTerm) ||
                            ride.destinationGate.toLowerCase().includes(searchTerm) ||
                            ride.driverName.toLowerCase().includes(searchTerm) ||
                            ride.pickupLandmark.toLowerCase().includes(searchTerm);
      
      const matchesOrigin = !originVal || ride.originNeighborhood === originVal;
      const matchesDest = !destVal || ride.destinationGate === destVal;
      const matchesVehicle = !vehicleVal || ride.vehicleType === vehicleVal;
      const matchesWomenOnly = !womenOnlyVal || ride.isWomenOnly === true;

      return matchesSearch && matchesOrigin && matchesDest && matchesVehicle && matchesWomenOnly;
    });

    renderRides(filteredRides);
  }

  // Event Listeners for Filters
  searchInput.addEventListener('input', applyFilters);
  originFilter.addEventListener('change', applyFilters);
  destinationFilter.addEventListener('change', applyFilters);
  vehicleFilter.addEventListener('change', applyFilters);
  womenOnlyToggle.addEventListener('change', applyFilters);

  // Modal Controllers
  btnOfferRide.addEventListener('click', () => offerRideModal.classList.add('active'));
  closeOfferModal.addEventListener('click', () => offerRideModal.classList.remove('active'));
  closeBookModal.addEventListener('click', () => bookRideModal.classList.remove('active'));
  closePassModal.addEventListener('click', () => ridePassModal.classList.remove('active'));

  // Transparent Fuel Cost Amortization Calculator logic
  function calculateFuelCost() {
    const dist = parseFloat(calcDistance.value) || 0;
    const mileage = parseFloat(calcMileage.value) || 15;
    const price = parseFloat(calcFuelPrice.value) || 102;
    const seats = parseInt(calcSeats.value) || 3;

    if (dist > 0 && mileage > 0 && seats > 0) {
      const totalFuelLitres = dist / mileage;
      const totalTripFuelCost = totalFuelLitres * price;
      const perSeatSplit = Math.round(totalTripFuelCost / seats);
      calculatedCostVal.textContent = `₹${perSeatSplit} per seat`;
      return perSeatSplit;
    } else {
      calculatedCostVal.textContent = `₹0 per seat`;
      return 0;
    }
  }

  [calcDistance, calcMileage, calcFuelPrice, calcSeats].forEach(input => {
    input.addEventListener('input', calculateFuelCost);
  });

  // Handle Offer Ride Form Submission
  offerRideForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const email = document.getElementById('driverEmail').value.trim();
    if (!email.endsWith('@campus.edu') && !email.endsWith('@univ.ac.in')) {
      alert('Verification Failed: Only accredited university email addresses (@campus.edu / @univ.ac.in) can publish rides.');
      return;
    }

    const perSeatCost = calculateFuelCost();

    const newRide = {
      id: `RIDE-${Date.now().toString().slice(-4)}`,
      driverName: document.getElementById('driverName').value.trim(),
      driverEmail: email,
      driverRating: 5.0,
      driverGender: document.getElementById('driverGender').value,
      vehicleType: document.getElementById('vehicleType').value,
      vehicleModel: document.getElementById('vehicleModel').value.trim() || 'Vehicle',
      originNeighborhood: document.getElementById('originNeighborhood').value.trim(),
      destinationGate: document.getElementById('destinationGate').value,
      departureTime: document.getElementById('departureTime').value,
      availableSeats: parseInt(calcSeats.value),
      totalSeats: parseInt(calcSeats.value),
      fuelSplitPerSeat: perSeatCost,
      isWomenOnly: document.getElementById('offerWomenOnly').checked,
      distanceKm: parseFloat(calcDistance.value),
      vehicleMileageKmpl: parseFloat(calcMileage.value),
      pickupLandmark: document.getElementById('pickupLandmark').value.trim() || 'Campus Main Entrance',
      verifiedEmail: true
    };

    rides.unshift(newRide);
    
    // Save to localStorage
    const savedLocalRides = JSON.parse(localStorage.getItem('rideRelay_custom_rides') || '[]');
    savedLocalRides.unshift(newRide);
    localStorage.setItem('rideRelay_custom_rides', JSON.stringify(savedLocalRides));

    offerRideModal.classList.remove('active');
    offerRideForm.reset();
    applyFilters();
    alert('🚗 Ride successfully offered and published to verified campus commuters!');
  });

  // Open Booking Modal Function (Exposed globally for onclick)
  window.openBookingModal = function(rideId) {
    const ride = rides.find(r => r.id === rideId);
    if (!ride) return;

    bookRideIdInput.value = ride.id;
    document.getElementById('modalRideTitle').textContent = `Book Ride with ${ride.driverName}`;
    
    // Seat Selector Options up to availableSeats
    bookSeatsSelect.innerHTML = '';
    for (let i = 1; i <= ride.availableSeats; i++) {
      const opt = document.createElement('option');
      opt.value = i;
      opt.textContent = `${i} Seat${i > 1 ? 's' : ''} (₹${ride.fuelSplitPerSeat * i})`;
      bookSeatsSelect.appendChild(opt);
    }

    updateBookingSummary(ride, 1);
    
    bookSeatsSelect.onchange = (e) => {
      updateBookingSummary(ride, parseInt(e.target.value));
    };

    bookRideModal.classList.add('active');
  };

  function updateBookingSummary(ride, count) {
    const totalCost = ride.fuelSplitPerSeat * count;
    bookingCostSummary.innerHTML = `
      <div style="background: #f1f5f9; padding: 0.8rem; border-radius: 6px;">
        <div style="font-size: 0.85rem; color: #64748b;">Route: <strong>${ride.originNeighborhood} ➔ ${ride.destinationGate}</strong></div>
        <div style="font-size: 0.85rem; color: #64748b; margin-top: 0.2rem;">Pickup: <strong>${ride.pickupLandmark}</strong></div>
        <div style="font-size: 1.1rem; font-weight: 800; color: #10b981; margin-top: 0.4rem;">Total Payable: ₹${totalCost}</div>
      </div>
    `;
  }

  // Handle Booking Submission & Digital Pass Generation
  bookingForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const passengerEmail = document.getElementById('passengerEmail').value.trim();
    if (!passengerEmail.endsWith('@campus.edu') && !passengerEmail.endsWith('@univ.ac.in')) {
      alert('Verification Failed: You must enter a valid accredited campus email (@campus.edu / @univ.ac.in) to book seats.');
      return;
    }

    const rideId = bookRideIdInput.value;
    const ride = rides.find(r => r.id === rideId);
    if (!ride) return;

    const seatsRequested = parseInt(bookSeatsSelect.value);
    if (ride.availableSeats < seatsRequested) {
      alert('Sorry, seats no longer available.');
      return;
    }

    // Decrement available seats state
    ride.availableSeats -= seatsRequested;
    
    bookRideModal.classList.remove('active');
    renderRides(filteredRides);

    // Generate Digital Ride Pass
    generateRidePass(ride, seatsRequested, document.getElementById('passengerName').value.trim(), passengerEmail);
  });

  // Generate Digital Ride Pass Modal
  function generateRidePass(ride, seats, passengerName, passengerEmail) {
    const passId = `PASS-${Math.floor(100000 + Math.random() * 900000)}`;
    const totalAmount = ride.fuelSplitPerSeat * seats;
    const upiHandle = `${ride.driverEmail.split('@')[0]}@okaxis`;

    document.getElementById('passContentContainer').innerHTML = `
      <div class="ride-pass-card">
        <div class="pass-header">
          <span class="pass-title">🎫 CAMPUS RIDE PASS</span>
          <span class="pass-id">${passId}</span>
        </div>
        <div class="pass-body">
          <div class="pass-row">
            <span class="label">Commuter:</span>
            <span class="val">${passengerName} (${passengerEmail})</span>
          </div>
          <div class="pass-row">
            <span class="label">Host Driver:</span>
            <span class="val">${ride.driverName} (${ride.driverEmail})</span>
          </div>
          <div class="pass-row">
            <span class="label">Route:</span>
            <span class="val">${ride.originNeighborhood} ➔ ${ride.destinationGate}</span>
          </div>
          <div class="pass-row">
            <span class="label">Departure Time:</span>
            <span class="val">⏰ ${ride.departureTime}</span>
          </div>
          <div class="pass-row">
            <span class="label">Vehicle:</span>
            <span class="val">${ride.vehicleModel}</span>
          </div>
          <div class="pass-row">
            <span class="label">Pickup Landmark:</span>
            <span class="val">📍 ${ride.pickupLandmark}</span>
          </div>
          <div class="pass-row">
            <span class="label">Seats Reserved:</span>
            <span class="val">${seats} Seat${seats > 1 ? 's' : ''}</span>
          </div>

          <div class="upi-box">
            <div class="upi-title">Direct P2P Fuel Split Reimbursement</div>
            <div class="upi-id">UPI: ${upiHandle}</div>
            <div style="font-size: 0.85rem; color: #a7f3d0; margin-top: 0.2rem;">Total Amount Due: ₹${totalAmount}</div>
          </div>
        </div>
      </div>
      <div style="margin-top: 1rem; text-align: center;">
        <p style="font-size: 0.85rem; color: #64748b;">Show this digital Ride Pass to your driver at pickup.</p>
      </div>
    `;

    ridePassModal.classList.add('active');
  }

  // Fallback Rides Data if local JSON file cannot be fetched via local file protocol
  function getFallbackRides() {
    return [
      {
        id: "RIDE-101",
        driverName: "Sneha Rao",
        driverEmail: "sneha.rao@campus.edu",
        driverRating: 4.9,
        driverGender: "Female",
        vehicleType: "Car",
        vehicleModel: "Honda City (White)",
        originNeighborhood: "Indiranagar",
        destinationGate: "Main Entrance",
        departureTime: "08:30 AM",
        availableSeats: 2,
        totalSeats: 4,
        fuelSplitPerSeat: 45,
        isWomenOnly: true,
        distanceKm: 12.5,
        vehicleMileageKmpl: 15,
        pickupLandmark: "Indiranagar Metro Station Gate 2",
        verifiedEmail: true
      },
      {
        id: "RIDE-102",
        driverName: "Rohan Verma",
        driverEmail: "rohan.v@univ.ac.in",
        driverRating: 4.8,
        driverGender: "Male",
        vehicleType: "Car",
        vehicleModel: "Hyundai i20 (Silver)",
        originNeighborhood: "Koramangala",
        destinationGate: "North Gate",
        departureTime: "08:15 AM",
        availableSeats: 3,
        totalSeats: 4,
        fuelSplitPerSeat: 40,
        isWomenOnly: false,
        distanceKm: 14.0,
        vehicleMileageKmpl: 16,
        pickupLandmark: "Koramangala Sony World Signal",
        verifiedEmail: true
      },
      {
        id: "RIDE-103",
        driverName: "Ananya Sharma",
        driverEmail: "ananya.s@campus.edu",
        driverRating: 4.95,
        driverGender: "Female",
        vehicleType: "Two-Wheeler",
        vehicleModel: "TVS Jupiter (Matte Black)",
        originNeighborhood: "HSR Layout",
        destinationGate: "Canteen Circle",
        departureTime: "08:45 AM",
        availableSeats: 1,
        totalSeats: 1,
        fuelSplitPerSeat: 25,
        isWomenOnly: true,
        distanceKm: 9.0,
        vehicleMileageKmpl: 45,
        pickupLandmark: "HSR BDA Complex Entrance",
        verifiedEmail: true
      }
    ];
  }

  // Initialize Data
  fetchRides();
});
