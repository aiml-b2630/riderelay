# 🚗 RideRelay: Verified Campus Carpooling & Fuel Cost Sharing Application

**RideRelay** is a verified peer-to-peer campus carpooling web application engineered specifically for university day-scholars, commuting students, and faculty. It enables daily commuters along shared residential corridors to match routes, book available seats, and split fuel costs transparently.

---

## 📌 Project Modules Architecture

### 🔹 Static Phase (Modules 1–2: HTML5, CSS3 & Flexbox Layout)
- **Campus Carpool Info Page**: Hero section framing the problem context (surge pricing, overcrowded buses, late-night campus safety) and introducing the verified peer-to-peer solution.
- **Flexbox Ride Feed & Cards**: Card layout using CSS Flexbox for adaptive, responsive presentation across mobile devices and desktop screens.
- **Status Badges & Vehicle Tags**: Clear visual indicators for driver ratings, vehicle types (Car / Two-Wheeler), departure times, fuel split cost badges, and verified student/faculty credentials.

### 🔹 Dynamic Phase (Modules 3–4: JavaScript, TypeScript Data Contracts & Fetch API)
- **Verified Campus Email Authentication Gate**: Restricts ride offering and seat booking to users with accredited university email domains (`@campus.edu` / `@univ.ac.in`).
- **Search & Filter Engine**: Real-time filtering by pickup neighborhood (Koramangala, Indiranagar, HSR Layout, Whitefield, etc.), destination campus gates (Main Entrance, North Gate, Canteen Circle, South Gate), and vehicle types.
- **Women-Only Safety Filter**: Dedicated toggle filter allowing female students and faculty to match exclusively with female drivers and co-riders.
- **Offer a Ride Workflow**: Modal interface allowing drivers to post daily commute schedules, vehicle models, available seat capacity, meeting landmarks, and trip details.
- **Transparent Fuel Cost Amortization Calculator**: Real-time per-seat fuel cost calculation based on trip distance, vehicle mileage (km/L), fuel price (₹/L), and available seats:
  $$\text{Per Seat Cost} = \frac{(\text{Distance} / \text{Mileage}) \times \text{Fuel Price}}{\text{Total Seats}}$$
- **Instant Seat Booking & Digital Ride Pass**: Seat reservation logic with seat decrement state management, generating a digital **Ride Pass** card with trip details and a direct P2P UPI reimbursement link (`upi://pay`).

---

## 📁 Repository & Directory Layout

```text
RideRelay/
├── index.html            # Main semantic HTML5 application entry point
├── css/
│   └── styles.css        # CSS3 custom variables, Flexbox layouts & responsive media queries
├── js/
│   ├── app.js            # Dynamic application logic (Fetch API, filters, state management, modals)
│   └── types.ts          # TypeScript interfaces (User, Ride, BookingRequest, DigitalRidePass)
├── data/
│   └── rides.json        # Carpool dataset (12 active campus rides across major residential hubs)
├── package.json          # Node.js project configuration & build scripts
├── tsconfig.json         # TypeScript compiler configuration
└── README.md             # Comprehensive project documentation
```

---

## 🚀 How to Run the Application

### Option 1: Open Directly in Browser
Double-click `index.html` or open it in any modern web browser (Chrome, Firefox, Safari, Edge). The application includes an inline fallback dataset so all interactive features (search, filtering, offering rides, calculating fuel splits, booking seats, and generating Ride Passes) work seamlessly out of the box.

### Option 2: Run via Local Web Server (Node.js)
```bash
# Navigate to project root
cd RideRelay

# Install dependencies and start server
npm start
```
Open `http://localhost:3000` or `http://localhost:5000` in your web browser.

---

## 🛠️ Tech Stack & Key Libraries
- **Language**: TypeScript (ES2022) / JavaScript (ES6+)
- **Styling**: Modern CSS3 (Flexbox, CSS Variables, Responsive Viewports)
- **Data Transfer**: Typed Fetch API data contracts & JSON dataset
- **State Management**: LocalStorage persistence & reactive UI updates
