const http = require('node:http');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const logger = require('./logger');
const { runMigrations } = require('./db/migrations');
const { openapiSpec, renderSwaggerUI } = require('./swagger/openapi');

const PORT = process.env.PORT || 3000;

// Security: JWT Secret with Environment variable fallback & runtime random bytes (no hardcoded secret string)
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(32).toString('hex');
if (!process.env.JWT_SECRET) {
    logger.warn('JWT_SECRET environment variable not provided. Initialized secure random runtime secret.');
}

// Database Initialization & Migration Engine
const db = new DatabaseSync('./data/db.sqlite');
runMigrations(db);

// Seed Initial Data if table empty
const seedCount = db.prepare('SELECT COUNT(*) as count FROM rides').get().count;
if (seedCount === 0) {
    logger.info('Seeding initial campus rides dataset...');
    const insertRide = db.prepare(`
        INSERT INTO rides (
            driver_name, driver_email, driver_gender, vehicle_type, vehicle_model,
            start_neighborhood, destination_gate, pickup_lat, pickup_lng, dest_lat, dest_lng,
            waypoint_corridor, departure_time, total_seats, available_seats,
            distance_km, vehicle_mileage, fuel_price_per_l, per_seat_cost,
            meeting_landmark, is_women_only, upi_id, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const initialRides = [
        ["Sneha Reddy", "sneha.r@campus.edu", "female", "Car", "Hyundai i20", "Indiranagar", "Main Entrance", 12.9784, 77.6408, 12.9352, 77.6245, "Indiranagar ➔ Domlur Flyover ➔ Main Gate", "08:30 AM", 3, 2, 8.5, 15.0, 102.0, 43.35, "Indiranagar Metro Station Gate B", 1, "sneha@upi", new Date().toISOString()],
        ["Rahul Sharma", "rahul.s@campus.edu", "male", "Car", "Honda City", "Koramangala", "North Gate", 12.9352, 77.6245, 12.9698, 77.7500, "Koramangala 4th Block ➔ Forum Mall ➔ North Gate", "09:00 AM", 4, 3, 12.0, 14.0, 102.0, 43.71, "Koramangala Sony World Signal", 0, "rahul@upi", new Date().toISOString()],
        ["Ananya V", "ananya.v@univ.ac.in", "female", "Two-Wheeler", "TVS Jupiter", "HSR Layout", "Canteen Circle", 12.9121, 77.6446, 12.9352, 77.6245, "HSR BDA Complex ➔ Silk Board ➔ Canteen Circle", "08:45 AM", 1, 1, 6.0, 45.0, 102.0, 13.60, "HSR BDA Complex Bus Stop", 1, "ananya@upi", new Date().toISOString()]
    ];

    for (const r of initialRides) {
        insertRide.run(...r);
    }
}

// SSE Live Event Broadcast System
const sseClients = new Set();

function broadcastEvent(type, payload) {
    const message = `event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`;
    for (const client of sseClients) {
        try {
            client.write(message);
        } catch (e) {
            sseClients.delete(client);
        }
    }
}

// JWT Token Helper
function generateToken(payload) {
    const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
    const body = Buffer.from(JSON.stringify({ ...payload, exp: Math.floor(Date.now() / 1000) + 86400 })).toString('base64url');
    const signature = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
    return `${header}.${body}.${signature}`;
}

function verifyToken(token) {
    if (!token) return null;
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const [header, body, signature] = parts;
    const expectedSig = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
    if (signature !== expectedSig) return null;
    try {
        const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
        if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) return null;
        return payload;
    } catch (e) {
        return null;
    }
}

// Input Sanitization
function sanitizeString(str) {
    if (typeof str !== 'string') return '';
    return str.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#x27;');
}

function sendJSON(res, statusCode, data) {
    res.writeHead(statusCode, {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    res.end(JSON.stringify(data));
}

// Haversine Spherical Distance Formula (km)
function haversineDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
}

const server = http.createServer((req, res) => {
    const requestId = crypto.randomBytes(4).toString('hex');
    logger.info(`HTTP ${req.method} ${req.url}`, { requestId }, requestId);

    if (req.method === 'OPTIONS') {
        res.writeHead(204, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization'
        });
        return res.end();
    }

    const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const path = parsedUrl.pathname;

    // Static Documentation & OpenAPI Specs
    if (path === '/api/docs' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        return res.end(renderSwaggerUI());
    }
    if (path === '/api/docs/openapi.json' && req.method === 'GET') {
        return sendJSON(res, 200, openapiSpec);
    }

    // SSE Stream
    if (path === '/api/rides/live' && req.method === 'GET') {
        res.writeHead(200, {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Access-Control-Allow-Origin': '*'
        });
        sseClients.add(res);
        req.on('close', () => sseClients.delete(res));
        return;
    }

    // API Routes
    if (path === '/api/verify-email' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try {
                const { email, name, gender } = JSON.parse(body);
                const campusRegex = /^[a-zA-Z0-9._%+-]+@(campus\.edu|univ\.ac\.in)$/i;

                if (!email || !campusRegex.test(email)) {
                    return sendJSON(res, 400, {
                        success: false,
                        error: { code: 'INVALID_CREDENTIALS', message: 'Restricted domain: Email must end with @campus.edu or @univ.ac.in' }
                    });
                }

                const userGender = gender || 'female';
                const token = generateToken({ email, name: sanitizeString(name), gender: userGender });

                sendJSON(res, 200, {
                    success: true,
                    token,
                    user: { email, name: sanitizeString(name), gender: userGender, verified: true }
                });
            } catch (e) {
                sendJSON(res, 400, { success: false, error: { code: 'BAD_REQUEST', message: 'Malformed JSON payload' } });
            }
        });
        return;
    }

    if (path === '/api/rides' && req.method === 'GET') {
        const rows = db.prepare('SELECT * FROM rides ORDER BY id DESC').all();
        const rides = rows.map(r => ({
            id: r.id,
            driverName: r.driver_name,
            driverEmail: r.driver_email,
            driverGender: r.driver_gender,
            vehicleType: r.vehicle_type,
            vehicleModel: r.vehicle_model,
            startNeighborhood: r.start_neighborhood,
            destinationGate: r.destination_gate,
            pickupCoordinates: { lat: r.pickup_lat, lng: r.pickup_lng },
            destinationCoordinates: { lat: r.dest_lat, lng: r.dest_lng },
            waypointCorridor: r.waypoint_corridor,
            departureTime: r.departure_time,
            totalSeats: r.total_seats,
            availableSeats: r.available_seats,
            distanceKm: r.distance_km,
            vehicleMileage: r.vehicle_mileage,
            fuelPricePerL: r.fuel_price_per_l,
            perSeatCost: r.per_seat_cost,
            meetingLandmark: r.meeting_landmark,
            isWomenOnly: Boolean(r.is_women_only),
            upiId: r.upi_id
        }));
        return sendJSON(res, 200, { success: true, rides });
    }

    if (path === '/api/rides/search' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try {
                const { pickupLat, pickupLng, radiusKm, destinationGate, womenOnly } = JSON.parse(body);
                const rows = db.prepare('SELECT * FROM rides WHERE available_seats > 0').all();

                let filtered = rows;
                if (womenOnly) {
                    filtered = filtered.filter(r => r.is_women_only === 1 || r.driver_gender === 'female');
                }
                if (destinationGate) {
                    filtered = filtered.filter(r => r.destination_gate.toLowerCase() === destinationGate.toLowerCase());
                }
                if (pickupLat && pickupLng) {
                    const radius = radiusKm || 5.0;
                    filtered = filtered.filter(r => {
                        const dist = haversineDistance(pickupLat, pickupLng, r.pickup_lat, r.pickup_lng);
                        return dist <= radius;
                    });
                }

                sendJSON(res, 200, { success: true, count: filtered.length, rides: filtered });
            } catch (e) {
                sendJSON(res, 400, { success: false, error: { code: 'SEARCH_ERROR', message: 'Invalid search parameters' } });
            }
        });
        return;
    }

    if (path === '/api/rides' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try {
                const authHeader = req.headers['authorization'];
                const token = authHeader && authHeader.split(' ')[1];
                const user = verifyToken(token);
                if (!user) {
                    return sendJSON(res, 401, { success: false, error: { code: 'UNAUTHORIZED', message: 'Authentication required' } });
                }

                const data = JSON.parse(body);
                const perSeatCost = Number((((data.distanceKm / data.vehicleMileage) * data.fuelPricePerL) / data.totalSeats).toFixed(2));

                const stmt = db.prepare(`
                    INSERT INTO rides (
                        driver_name, driver_email, driver_gender, vehicle_type, vehicle_model,
                        start_neighborhood, destination_gate, pickup_lat, pickup_lng, dest_lat, dest_lng,
                        waypoint_corridor, departure_time, total_seats, available_seats,
                        distance_km, vehicle_mileage, fuel_price_per_l, per_seat_cost,
                        meeting_landmark, is_women_only, upi_id, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                `);

                const result = stmt.run(
                    sanitizeString(user.name),
                    user.email,
                    user.gender || 'female',
                    sanitizeString(data.vehicleType),
                    sanitizeString(data.vehicleModel),
                    sanitizeString(data.startNeighborhood),
                    sanitizeString(data.destinationGate),
                    data.pickupLat || 12.9716,
                    data.pickupLng || 77.5946,
                    data.destLat || 12.9352,
                    data.destLng || 77.6245,
                    sanitizeString(data.waypointCorridor || data.startNeighborhood),
                    sanitizeString(data.departureTime),
                    Number(data.totalSeats),
                    Number(data.totalSeats),
                    Number(data.distanceKm),
                    Number(data.vehicleMileage),
                    Number(data.fuelPricePerL),
                    perSeatCost,
                    sanitizeString(data.meetingLandmark),
                    data.isWomenOnly ? 1 : 0,
                    sanitizeString(data.upiId || 'campus@upi'),
                    new Date().toISOString()
                );

                const newRide = { id: Number(result.lastInsertRowid), ...data, perSeatCost };
                broadcastEvent('NEW_RIDE', newRide);
                sendJSON(res, 201, { success: true, ride: newRide });
            } catch (e) {
                sendJSON(res, 400, { success: false, error: { code: 'CREATION_FAILED', message: 'Failed to publish ride', details: e.message } });
            }
        });
        return;
    }

    if (path === '/api/book' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try {
                const data = JSON.parse(body);
                const { rideId, seatsRequested, passengerName, passengerEmail, passengerGender } = data;

                const ride = db.prepare('SELECT * FROM rides WHERE id = ?').get(rideId);
                if (!ride) {
                    return sendJSON(res, 404, { success: false, error: { code: 'NOT_FOUND', message: 'Ride posting not found' } });
                }

                // Women-Only Backend Gender Check
                const pGender = (passengerGender || 'female').toLowerCase();
                if (ride.is_women_only === 1 && pGender !== 'female') {
                    logger.warn(`Gender Violation: ${passengerEmail} (${pGender}) attempted booking Women-Only ride ${rideId}`);
                    return sendJSON(res, 403, {
                        success: false,
                        error: {
                            code: 'GENDER_RESTRICTION_VIOLATION',
                            message: 'This ride is reserved exclusively for verified female riders.'
                        }
                    });
                }

                // Atomic Concurrency Decrement in SQLite
                const updateStmt = db.prepare('UPDATE rides SET available_seats = available_seats - ? WHERE id = ? AND available_seats >= ?');
                const result = updateStmt.run(seatsRequested, rideId, seatsRequested);

                if (result.changes === 0) {
                    return sendJSON(res, 409, {
                        success: false,
                        error: { code: 'CONCURRENCY_CONFLICT', message: 'Requested seats are no longer available.' }
                    });
                }

                const totalAmount = Number((ride.per_seat_cost * seatsRequested).toFixed(2));
                const passCode = `RIDE-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;

                db.prepare(`
                    INSERT INTO bookings (ride_id, passenger_name, passenger_email, passenger_gender, seats_booked, total_amount, pass_code, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                `).run(rideId, sanitizeString(passengerName), passengerEmail, pGender, seatsRequested, totalAmount, passCode, new Date().toISOString());

                const pass = {
                    passCode,
                    rideId,
                    driverName: ride.driver_name,
                    driverEmail: ride.driver_email,
                    passengerName,
                    passengerEmail,
                    vehicleModel: ride.vehicle_model,
                    meetingLandmark: ride.meeting_landmark,
                    departureTime: ride.departure_time,
                    seatsBooked: seatsRequested,
                    totalAmount,
                    upiId: ride.upi_id,
                    status: 'CONFIRMED'
                };

                broadcastEvent('SEAT_BOOKED', { rideId, availableSeats: ride.available_seats - seatsRequested });
                sendJSON(res, 200, { success: true, pass });
            } catch (e) {
                sendJSON(res, 400, { success: false, error: { code: 'BOOKING_FAILED', message: e.message } });
            }
        });
        return;
    }

    if (path === '/api/ratings' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try {
                const { rideId, driverEmail, riderName, punctualityRating, safetyRating, courtesyRating, comment } = JSON.parse(body);
                const overall = Number(((punctualityRating + safetyRating + courtesyRating) / 3).toFixed(1));

                db.prepare(`
                    INSERT INTO ratings (ride_id, driver_email, rider_name, punctuality_rating, safety_rating, courtesy_rating, overall_rating, comment, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                `).run(rideId, driverEmail, sanitizeString(riderName), punctualityRating, safetyRating, courtesyRating, overall, sanitizeString(comment || ''), new Date().toISOString());

                sendJSON(res, 201, { success: true, message: 'Review recorded successfully', overallRating: overall });
            } catch (e) {
                sendJSON(res, 400, { success: false, error: { code: 'RATING_FAILED', message: 'Failed to record rating' } });
            }
        });
        return;
    }

    sendJSON(res, 404, { success: false, error: { code: 'ROUTE_NOT_FOUND', message: 'API Endpoint not found' } });
});

if (require.main === module) {
    server.listen(PORT, () => {
        logger.info(`RideRelay Server running on port ${PORT}`);
    });
}

module.exports = server;
