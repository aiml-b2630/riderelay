/**
 * RideRelay Versioned Database Migration Strategy
 * Tracks applied migrations in `schema_migrations` table for robust data integrity.
 */
const { DatabaseSync } = require('node:sqlite');
const logger = require('../logger');

const MIGRATIONS = [
    {
        version: 1,
        name: '001_initial_schema',
        sql: `
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                gender TEXT NOT NULL DEFAULT 'other',
                is_verified INTEGER DEFAULT 0,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS rides (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                driver_name TEXT NOT NULL,
                driver_email TEXT NOT NULL,
                driver_gender TEXT NOT NULL DEFAULT 'female',
                vehicle_type TEXT NOT NULL,
                vehicle_model TEXT NOT NULL,
                start_neighborhood TEXT NOT NULL,
                destination_gate TEXT NOT NULL,
                pickup_lat REAL NOT NULL,
                pickup_lng REAL NOT NULL,
                dest_lat REAL NOT NULL,
                dest_lng REAL NOT NULL,
                waypoint_corridor TEXT NOT NULL,
                departure_time TEXT NOT NULL,
                total_seats INTEGER NOT NULL,
                available_seats INTEGER NOT NULL,
                distance_km REAL NOT NULL,
                vehicle_mileage REAL NOT NULL,
                fuel_price_per_l REAL NOT NULL,
                per_seat_cost REAL NOT NULL,
                meeting_landmark TEXT NOT NULL,
                is_women_only INTEGER DEFAULT 0,
                upi_id TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS bookings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ride_id INTEGER NOT NULL,
                passenger_name TEXT NOT NULL,
                passenger_email TEXT NOT NULL,
                passenger_gender TEXT NOT NULL,
                seats_booked INTEGER NOT NULL,
                total_amount REAL NOT NULL,
                pass_code TEXT UNIQUE NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (ride_id) REFERENCES rides(id)
            );

            CREATE TABLE IF NOT EXISTS ratings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ride_id INTEGER NOT NULL,
                driver_email TEXT NOT NULL,
                rider_name TEXT NOT NULL,
                punctuality_rating INTEGER NOT NULL,
                safety_rating INTEGER NOT NULL,
                courtesy_rating INTEGER NOT NULL,
                overall_rating REAL NOT NULL,
                comment TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (ride_id) REFERENCES rides(id)
            );
        `
    },
    {
        version: 2,
        name: '002_add_indices_and_constraints',
        sql: `
            CREATE INDEX IF NOT EXISTS idx_rides_start ON rides(start_neighborhood);
            CREATE INDEX IF NOT EXISTS idx_rides_dest ON rides(destination_gate);
            CREATE INDEX IF NOT EXISTS idx_rides_women_only ON rides(is_women_only);
            CREATE INDEX IF NOT EXISTS idx_bookings_ride ON bookings(ride_id);
        `
    }
];

function runMigrations(db) {
    db.exec(`
        CREATE TABLE IF NOT EXISTS schema_migrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            version INTEGER UNIQUE NOT NULL,
            name TEXT NOT NULL,
            applied_at TEXT NOT NULL
        );
    `);

    const stmt = db.prepare('SELECT version FROM schema_migrations');
    const appliedVersions = new Set(stmt.all().map(r => r.version));

    for (const mig of MIGRATIONS) {
        if (!appliedVersions.has(mig.version)) {
            logger.info(`Applying Database Migration v${mig.version}: ${mig.name}`);
            db.exec(mig.sql);
            const insertStmt = db.prepare('INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)');
            insertStmt.run(mig.version, mig.name, new Date().toISOString());
        }
    }
    logger.info('All database migrations applied successfully.');
}

module.exports = { runMigrations };
