/**
 * RideRelay Structured Production Logger
 * Outputs JSON log events with ISO timestamps, log levels, request IDs, and metadata.
 */
class Logger {
    constructor() {
        this.levels = { DEBUG: 10, INFO: 20, WARN: 30, ERROR: 40 };
        this.currentLevel = process.env.LOG_LEVEL || 'INFO';
    }

    _format(level, message, meta = {}, requestId = null) {
        return JSON.stringify({
            timestamp: new Date().toISOString(),
            level,
            requestId: requestId || 'sys',
            message,
            ...meta
        });
    }

    info(message, meta, requestId) {
        console.log(this._format('INFO', message, meta, requestId));
    }

    warn(message, meta, requestId) {
        console.warn(this._format('WARN', message, meta, requestId));
    }

    error(message, meta, requestId) {
        console.error(this._format('ERROR', message, meta, requestId));
    }

    debug(message, meta, requestId) {
        if (this.levels[this.currentLevel] <= 10) {
            console.log(this._format('DEBUG', message, meta, requestId));
        }
    }
}

module.exports = new Logger();
