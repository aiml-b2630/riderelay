/**
 * RideRelay API Client Engine with SSE Live Listener & JWT Injection
 */
let authToken = localStorage.getItem('riderelay_jwt_token') || null;

export function setAuthToken(token) {
    authToken = token;
    if (token) {
        localStorage.setItem('riderelay_jwt_token', token);
    } else {
        localStorage.removeItem('riderelay_jwt_token');
    }
}

export function getAuthToken() {
    return authToken;
}

export async function apiRequest(endpoint, method = 'GET', data = null) {
    const headers = { 'Content-Type': 'application/json' };
    if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`;
    }

    const config = { method, headers };
    if (data && (method === 'POST' || method === 'PUT')) {
        config.body = JSON.stringify(data);
    }

    try {
        const response = await fetch(endpoint, config);
        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.error?.message || `HTTP ${response.status} Error`);
        }
        return result;
    } catch (err) {
        console.error(`API Error [${method} ${endpoint}]:`, err);
        throw err;
    }
}

export function connectLiveSSE(onRideUpdate) {
    if (typeof EventSource !== 'undefined') {
        const evtSource = new EventSource('/api/rides/live');
        evtSource.addEventListener('SEAT_BOOKED', (e) => {
            const data = JSON.parse(e.data);
            if (onRideUpdate) onRideUpdate('SEAT_BOOKED', data);
        });
        evtSource.addEventListener('NEW_RIDE', (e) => {
            const data = JSON.parse(e.data);
            if (onRideUpdate) onRideUpdate('NEW_RIDE', data);
        });
        return evtSource;
    }
    return null;
}
