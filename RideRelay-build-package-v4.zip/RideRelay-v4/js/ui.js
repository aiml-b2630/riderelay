/**
 * RideRelay v3.0 - Modern UI Components, Cards & Accessible Toast Banners
 */

export function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ'}</span>
    <span class="toast-message">${message}</span>
  `;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

export function renderRideCard(ride, currentEmail) {
  const isFemaleBadge = ride.is_female ? '<span class="badge badge-women">👩 Women-Only</span>' : '';
  const vehicleBadge = ride.vehicle_type === 'Car' ? '🚗 Car' : '🛵 Bike';
  const waypointsCount = ride.waypoints ? ride.waypoints.length : 0;

  return `
    <article class="ride-card" data-id="${ride.id}">
      <div class="card-header">
        <div class="host-info">
          <h3>${ride.host_name} <span class="role-badge">${ride.host_role}</span></h3>
          <div class="rating-stars">★ ${ride.rating || 5.0} / 5.0</div>
        </div>
        <div class="badge-group">
          ${isFemaleBadge}
          <span class="badge badge-vehicle">${vehicleBadge}</span>
        </div>
      </div>

      <div class="route-details">
        <div class="route-point">
          <span class="dot green"></span>
          <div>
            <strong>Pickup:</strong> ${ride.start_location}
            <small class="coord-badge">(${ride.start_lat.toFixed(3)}, ${ride.start_lng.toFixed(3)})</small>
          </div>
        </div>
        ${waypointsCount > 0 ? `
          <div class="route-waypoints">
            ↳ 📍 Stops: ${ride.waypoints.map(w => w.name).join(' → ')}
          </div>
        ` : ''}
        <div class="route-point">
          <span class="dot red"></span>
          <div>
            <strong>Destination:</strong> ${ride.destination_gate}
          </div>
        </div>
      </div>

      <div class="card-meta">
        <div>🕒 <strong>${ride.departure_time}</strong></div>
        <div>👥 <strong>${ride.available_seats} / ${ride.total_seats} seats</strong></div>
        <div class="cost-tag">💰 <strong>₹${ride.per_seat_cost}</strong> / seat</div>
      </div>

      <div class="landmark-info">
        📍 <em>Meeting: ${ride.meeting_landmark}</em>
      </div>

      <div class="card-actions">
        <button class="btn btn-primary book-btn" data-id="${ride.id}" ${ride.available_seats <= 0 ? 'disabled' : ''}>
          ${ride.available_seats > 0 ? 'Book Seat' : 'Full'}
        </button>
        <button class="btn btn-secondary rate-btn" data-id="${ride.id}" data-email="${ride.host_email}" data-name="${ride.host_name}">
          Rate Driver
        </button>
      </div>
    </article>
  `;
}
