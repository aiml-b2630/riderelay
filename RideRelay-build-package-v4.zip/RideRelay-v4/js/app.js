import { apiRequest, setAuthToken, connectLiveSSE } from './api.js';
import { renderRideCards, showToast, renderPassCard, showModal, hideModal } from './ui.js';
import { haversineDistance, filterRidesByProximity } from './matching.js';
import { initRatingsStudio } from './ratings.js';
import { initOfflineHandler, cacheRidesLocally, getCachedRides } from './offline.js';

let currentUser = JSON.parse(localStorage.getItem('riderelay_user')) || null;
let allRides = [];

document.addEventListener('DOMContentLoaded', () => {
    initOfflineHandler();
    initApp();
});

async function initApp() {
    updateAuthUI();
    initRatingsStudio();
    await loadRidesFeed();
    setupEventListeners();

    // Connect Live SSE
    connectLiveSSE((type, payload) => {
        if (type === 'SEAT_BOOKED') {
            const ride = allRides.find(r => r.id === payload.rideId);
            if (ride) {
                ride.availableSeats = payload.availableSeats;
                renderRideCards(allRides, handleBookRideClick);
            }
        } else if (type === 'NEW_RIDE') {
            loadRidesFeed();
            showToast('New campus ride posted in real-time!', 'info');
        }
    });
}

function updateAuthUI() {
    const authStatus = document.getElementById('authStatus');
    const authBtn = document.getElementById('authBtn');
    if (currentUser) {
        authStatus.innerHTML = `<span class="badge badge-verified">✓ ${currentUser.name} (${currentUser.gender})</span>`;
        authBtn.textContent = 'Switch Account';
    } else {
        authStatus.innerHTML = `<span class="badge badge-unverified">🔒 Guest (Unverified)</span>`;
        authBtn.textContent = 'Verify Campus Email';
    }
}

async function loadRidesFeed() {
    try {
        const res = await apiRequest('/api/rides');
        if (res.success) {
            allRides = res.rides;
            cacheRidesLocally(allRides);
            renderRideCards(allRides, handleBookRideClick);
        }
    } catch (err) {
        console.warn('Network fetch failed, attempting local fallback cache...', err);
        const cached = getCachedRides();
        if (cached.length > 0) {
            allRides = cached;
            renderRideCards(allRides, handleBookRideClick);
            showToast('Loaded active rides from offline local cache.', 'info');
        } else {
            showToast('Failed to load rides feed.', 'error');
        }
    }
}

function handleBookRideClick(rideId) {
    if (!currentUser) {
        showToast('Please verify your campus email credentials first.', 'error');
        openAuthModal();
        return;
    }

    const ride = allRides.find(r => r.id === rideId);
    if (!ride) return;

    if (ride.isWomenOnly && currentUser.gender.toLowerCase() !== 'female') {
        showToast('Access Restricted: This ride is reserved exclusively for verified female riders.', 'error');
        return;
    }

    openBookingModal(ride);
}

function openAuthModal() {
    showModal('authModal');
}

function openBookingModal(ride) {
    const content = document.getElementById('bookingModalContent');
    content.innerHTML = `
        <div class="booking-summary">
            <h3>Book Seat with ${ride.driverName}</h3>
            <p><strong>Route:</strong> ${ride.startNeighborhood} ➔ ${ride.destinationGate}</p>
            <p><strong>Departure:</strong> ${ride.departureTime} | <strong>Landmark:</strong> ${ride.meetingLandmark}</p>
            <p><strong>Per Seat Fuel Contribution:</strong> ₹${ride.perSeatCost}</p>
            ${ride.isWomenOnly ? '<p><span class="badge badge-women">👩 Women-Only Verified</span></p>' : ''}
            
            <form id="bookingForm" class="form-group" style="margin-top:1rem;">
                <label>Passenger Name</label>
                <input type="text" id="passName" value="${currentUser.name}" required readonly>
                <label>Passenger Email</label>
                <input type="email" id="passEmail" value="${currentUser.email}" required readonly>
                <label>Passenger Gender</label>
                <input type="text" id="passGender" value="${currentUser.gender}" required readonly>
                
                <label>Seats Requested</label>
                <select id="seatCount">
                    ${Array.from({ length: ride.availableSeats }, (_, i) => `<option value="${i + 1}">${i + 1} Seat(s)</option>`).join('')}
                </select>

                <div style="margin-top:1.5rem; display:flex; gap:0.5rem;">
                    <button type="submit" class="btn btn-primary" style="flex:1;">Confirm & Get Digital Pass</button>
                    <button type="button" class="btn btn-secondary" id="cancelBookingBtn">Cancel</button>
                </div>
            </form>
        </div>
    `;

    showModal('bookingModal');

    document.getElementById('cancelBookingBtn').onclick = () => hideModal('bookingModal');
    document.getElementById('bookingForm').onsubmit = async (e) => {
        e.preventDefault();
        const seats = Number(document.getElementById('seatCount').value);

        try {
            const res = await apiRequest('/api/book', 'POST', {
                rideId: ride.id,
                seatsRequested: seats,
                passengerName: currentUser.name,
                passengerEmail: currentUser.email,
                passengerGender: currentUser.gender
            });

            if (res.success) {
                hideModal('bookingModal');
                renderPassCard(res.pass);
                showToast('Seat booked successfully! Ride Pass generated.', 'success');
                await loadRidesFeed();
            }
        } catch (err) {
            showToast(err.message || 'Booking failed.', 'error');
        }
    };
}

function setupEventListeners() {
    document.getElementById('authBtn').onclick = openAuthModal;
    document.getElementById('closeAuthModal').onclick = () => hideModal('authModal');
    document.getElementById('closeBookingModal').onclick = () => hideModal('bookingModal');

    document.getElementById('authForm').onsubmit = async (e) => {
        e.preventDefault();
        const email = document.getElementById('authEmail').value.trim();
        const name = document.getElementById('authName').value.trim();
        const gender = document.getElementById('authGender').value;

        try {
            const res = await apiRequest('/api/verify-email', 'POST', { email, name, gender });
            if (res.success) {
                currentUser = res.user;
                setAuthToken(res.token);
                localStorage.setItem('riderelay_user', JSON.stringify(currentUser));
                updateAuthUI();
                hideModal('authModal');
                showToast(`Verified as ${currentUser.name} (${currentUser.gender})`, 'success');
            }
        } catch (err) {
            showToast(err.message || 'Campus email verification failed.', 'error');
        }
    };

    // Filter Listeners
    document.getElementById('searchInput').oninput = applyFilters;
    document.getElementById('gateFilter').onchange = applyFilters;
    document.getElementById('womenFilter').onchange = applyFilters;

    // Offer Ride Form
    document.getElementById('offerRideBtn').onclick = () => {
        if (!currentUser) {
            showToast('Please verify your campus credentials first.', 'error');
            openAuthModal();
            return;
        }
        showModal('offerRideModal');
    };
    document.getElementById('closeOfferModal').onclick = () => hideModal('offerRideModal');

    document.getElementById('offerRideForm').onsubmit = async (e) => {
        e.preventDefault();
        const rideData = {
            vehicleType: document.getElementById('vType').value,
            vehicleModel: document.getElementById('vModel').value,
            startNeighborhood: document.getElementById('startArea').value,
            destinationGate: document.getElementById('destGate').value,
            waypointCorridor: document.getElementById('corridor').value,
            departureTime: document.getElementById('depTime').value,
            totalSeats: Number(document.getElementById('seats').value),
            distanceKm: Number(document.getElementById('dist').value),
            vehicleMileage: Number(document.getElementById('mileage').value),
            fuelPricePerL: Number(document.getElementById('fuelPrice').value),
            meetingLandmark: document.getElementById('landmark').value,
            isWomenOnly: document.getElementById('womenOnlyCheck').checked,
            upiId: document.getElementById('upi').value
        };

        try {
            const res = await apiRequest('/api/rides', 'POST', rideData);
            if (res.success) {
                hideModal('offerRideModal');
                showToast('Campus ride posted successfully!', 'success');
                await loadRidesFeed();
            }
        } catch (err) {
            showToast(err.message || 'Failed to post ride.', 'error');
        }
    };
}

function applyFilters() {
    const query = document.getElementById('searchInput').value.toLowerCase();
    const gate = document.getElementById('gateFilter').value;
    const womenOnly = document.getElementById('womenFilter').checked;

    let filtered = allRides;

    if (query) {
        filtered = filtered.filter(r =>
            r.startNeighborhood.toLowerCase().includes(query) ||
            r.driverName.toLowerCase().includes(query) ||
            r.waypointCorridor.toLowerCase().includes(query)
        );
    }

    if (gate) {
        filtered = filtered.filter(r => r.destinationGate === gate);
    }

    if (womenOnly) {
        filtered = filtered.filter(r => r.isWomenOnly || r.driverGender === 'female');
    }

    renderRideCards(filtered, handleBookRideClick);
}
