/**
 * RideRelay v3.0 - Campus Commute Trust & Safety Rating Studio
 */

import { apiRequest } from './api.js';

export async function submitDriverRating(rideId, targetEmail, punctuality, safety, courtesy, comment) {
  return await apiRequest('/ratings', 'POST', {
    rideId, targetEmail, punctuality, safety, courtesy, comment
  });
}

export async function getDriverRatingBreakdown(driverEmail) {
  return await apiRequest(`/ratings/${encodeURIComponent(driverEmail)}`, 'GET');
}
