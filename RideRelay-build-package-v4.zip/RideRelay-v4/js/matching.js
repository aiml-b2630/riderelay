/**
 * RideRelay v3.0 - Milestone Route Matching Heuristics
 * Haversine Geographic Coordinate Proximity Calculation
 */

export function haversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Earth radius in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

export function matchRidesGeospatial(rides, riderPickup, maxRadiusKm = 3.0) {
  if (!riderPickup || typeof riderPickup.lat !== 'number') return rides;

  return rides.filter(ride => {
    // 1. Distance to driver's starting point
    const startDist = haversineDistance(riderPickup.lat, riderPickup.lng, ride.start_lat, ride.start_lng);
    if (startDist <= maxRadiusKm) return true;

    // 2. Distance to any intermediate route waypoints
    if (ride.waypoints && Array.isArray(ride.waypoints)) {
      return ride.waypoints.some(wp => haversineDistance(riderPickup.lat, riderPickup.lng, wp.lat, wp.lng) <= maxRadiusKm);
    }

    return false;
  });
}
