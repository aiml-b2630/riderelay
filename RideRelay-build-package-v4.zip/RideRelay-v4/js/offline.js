/**
 * RideRelay Offline Resilience & PWA Module
 */
export function initOfflineHandler() {
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);
    updateOnlineStatus();

    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/sw.js').catch((err) => {
            console.log('SW Registration bypassed or unavailable in current env:', err);
        });
    }
}

function updateOnlineStatus() {
    const offlineBanner = document.getElementById('offlineBanner');
    if (!navigator.onLine) {
        if (offlineBanner) offlineBanner.style.display = 'block';
    } else {
        if (offlineBanner) offlineBanner.style.display = 'none';
    }
}

export function cacheRidesLocally(rides) {
    try {
        localStorage.setItem('riderelay_cached_rides', JSON.stringify(rides));
    } catch (e) {
        console.warn('LocalStorage cache write failed', e);
    }
}

export function getCachedRides() {
    try {
        const cached = localStorage.getItem('riderelay_cached_rides');
        return cached ? JSON.parse(cached) : [];
    } catch (e) {
        return [];
    }
}
