/**
 * RideRelay v3.0 - TypeScript Data Contracts
 */

export interface GeoCoordinate {
  lat: number;
  lng: number;
}

export interface RouteWaypoint extends GeoCoordinate {
  name: string;
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: 'Student' | 'Faculty';
}

export interface Ride {
  id: string;
  host_name: string;
  host_email: string;
  host_role: 'Student' | 'Faculty';
  is_female: number | boolean;
  vehicle_type: 'Car' | 'Two-Wheeler';
  vehicle_model: string;
  start_location: string;
  start_lat: number;
  start_lng: number;
  destination_gate: string;
  dest_lat: number;
  dest_lng: number;
  waypoints: RouteWaypoint[];
  departure_time: string;
  available_seats: number;
  total_seats: number;
  distance_km: number;
  fuel_price: number;
  vehicle_mileage: number;
  per_seat_cost: number;
  meeting_landmark: string;
  upi_id: string;
  rating: number;
}

export interface RatingReview {
  id: string;
  ride_id: string;
  target_email: string;
  reviewer_email: string;
  punctuality: number;
  safety: number;
  courtesy: number;
  overall: number;
  comment: string;
  timestamp: string;
}

export interface DigitalRidePass {
  passId: string;
  passengerName: string;
  passengerEmail: string;
  hostName: string;
  hostEmail: string;
  vehicleModel: string;
  startLocation: string;
  destinationGate: string;
  departureTime: string;
  meetingLandmark: string;
  totalAmount: number;
  upiId: string;
}
