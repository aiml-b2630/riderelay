const assert = require('node:assert');
const { DatabaseSync } = require('node:sqlite');
const { runMigrations } = require('../db/migrations');

function testMigrationEngine() {
    const db = new DatabaseSync(':memory:');
    runMigrations(db);

    const migrations = db.prepare('SELECT * FROM schema_migrations ORDER BY version ASC').all();
    assert.strictEqual(migrations.length, 2, 'Should apply 2 schema migrations');
    assert.strictEqual(migrations[0].version, 1, 'First migration should be version 1');
    assert.strictEqual(migrations[1].version, 2, 'Second migration should be version 2');

    // Idempotency re-run check
    runMigrations(db);
    const reChecked = db.prepare('SELECT * FROM schema_migrations ORDER BY version ASC').all();
    assert.strictEqual(reChecked.length, 2, 'Re-running migrations should be idempotent');

    console.log('✓ Database Migration Strategy Test Passed');
}

module.exports = testMigrationEngine;
if (require.main === module) testMigrationEngine();
