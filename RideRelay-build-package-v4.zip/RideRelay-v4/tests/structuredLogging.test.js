const assert = require('node:assert');
const logger = require('../logger');

function testStructuredLogging() {
    const formatted = logger._format('INFO', 'Test log event', { userId: 42 }, 'req-123');
    const parsed = JSON.parse(formatted);

    assert.strictEqual(parsed.level, 'INFO');
    assert.strictEqual(parsed.message, 'Test log event');
    assert.strictEqual(parsed.userId, 42);
    assert.strictEqual(parsed.requestId, 'req-123');
    assert.ok(parsed.timestamp, 'Timestamp should be present');

    console.log('✓ Structured Production Logger Test Passed');
}

module.exports = testStructuredLogging;
if (require.main === module) testStructuredLogging();
