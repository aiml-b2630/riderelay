const assert = require('node:assert');
const { DatabaseSync } = require('node:sqlite');
const { runMigrations } = require('../db/migrations');

function testWomenOnlyGenderEnforcement() {
    const db = new DatabaseSync(':memory:');
    runMigrations(db);

    // Insert Women-Only Ride
    db.prepare(`
        INSERT INTO rides (
            driver_name, driver_email, driver_gender, vehicle_type, vehicle_model,
            start_neighborhood, destination_gate, pickup_lat, pickup_lng, dest_lat, dest_lng,
            waypoint_corridor, departure_time, total_seats, available_seats,
            distance_km, vehicle_mileage, fuel_price_per_l, per_seat_cost,
            meeting_landmark, is_women_only, upi_id, created_at
        ) VALUES (
            'Sneha Sharma', 'sneha@campus.edu', 'female', 'Car', 'Swift',
            'Indiranagar', 'Main Entrance', 12.9784, 77.6408, 12.9352, 77.6245,
            'Indiranagar Corridor', '08:30 AM', 3, 3, 10.0, 15.0, 102.0, 34.0,
            'Metro Station', 1, 'sneha@upi', '2026-11-24'
        )
    `).run();

    const ride = db.prepare('SELECT * FROM rides WHERE id = 1').get();

    // Check Female Passenger allowed
    const isFemaleAllowed = !(ride.is_women_only === 1 && 'female' !== 'female');
    assert.strictEqual(isFemaleAllowed, true, 'Female passenger should be allowed');

    // Check Male Passenger rejected
    const isMaleAllowed = !(ride.is_women_only === 1 && 'male' !== 'female');
    assert.strictEqual(isMaleAllowed, false, 'Male passenger should be blocked from Women-Only ride');

    console.log('✓ Women-Only Gender Enforcement Test Passed');
}

module.exports = testWomenOnlyGenderEnforcement;
if (require.main === module) testWomenOnlyGenderEnforcement();
