const assert = require('assert');
const { haversineDistanceKm } = require('../server.js');

function testHaversineProximity() {
  console.log('--- TEST 2: Haversine Geographic Proximity Calculation ---');

  // Indiranagar (12.9784, 77.6408) to Main Campus Gate (12.9340, 77.6080)
  const dist = haversineDistanceKm(12.9784, 77.6408, 12.9340, 77.6080);
  assert.ok(dist > 5.0 && dist < 10.0, `Calculated distance should be ~6.1 km, got ${dist}`);

  // Near pickup point test (0.5 km away)
  const nearDist = haversineDistanceKm(12.9784, 77.6408, 12.9800, 77.6410);
  assert.ok(nearDist < 1.0, 'Nearby point should be less than 1.0 km');

  console.log('✓ Haversine Geographic Distance Test Passed');
}

module.exports = testHaversineProximity;
