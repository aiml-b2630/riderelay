const assert = require('assert');
const { DatabaseSync } = require('node:sqlite');

function testSQLitePersistence() {
  console.log('--- TEST 1: SQLite Persistence & Atomic Seat Concurrency ---');
  const db = new DatabaseSync(':memory:');

  db.exec(`
    CREATE TABLE rides (id TEXT PRIMARY KEY, available_seats INTEGER);
    INSERT INTO rides VALUES ('RIDE-TEST', 3);
  `);

  // Book 2 seats atomically
  const stmt = db.prepare("UPDATE rides SET available_seats = available_seats - ? WHERE id = ? AND available_seats >= ?");
  const result = stmt.run(2, 'RIDE-TEST', 2);
  assert.strictEqual(result.changes, 1, 'Should change 1 row');

  const checkStmt = db.prepare("SELECT available_seats FROM rides WHERE id = 'RIDE-TEST'");
  const row = checkStmt.get();
  assert.strictEqual(row.available_seats, 1, 'Available seats should be decremented to 1');

  // Attempt to book 2 seats when only 1 is left (should fail atomically)
  const failResult = stmt.run(2, 'RIDE-TEST', 2);
  assert.strictEqual(failResult.changes, 0, 'Should not modify rows when seats insufficient');

  console.log('✓ SQLite Persistence & Atomic Seat Booking Test Passed');
}

module.exports = testSQLitePersistence;
