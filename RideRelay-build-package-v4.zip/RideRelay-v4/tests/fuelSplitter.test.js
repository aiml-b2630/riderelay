const assert = require('assert');

function testFuelSplitter() {
  console.log('--- TEST 4: Transparent Fuel Split Amortization Formula ---');

  const distanceKm = 9.5;
  const mileageKmL = 15.0;
  const fuelPricePerL = 102.5;
  const totalSeats = 3;

  const perSeatCost = (distanceKm / mileageKmL) * fuelPricePerL / totalSeats;
  const roundedCost = Math.round(perSeatCost * 100) / 100;

  assert.strictEqual(roundedCost, 21.64, `Expected per-seat cost to be ₹21.64, got ₹${roundedCost}`);
  console.log('✓ Fuel Split Amortization Formula Test Passed');
}

module.exports = testFuelSplitter;
