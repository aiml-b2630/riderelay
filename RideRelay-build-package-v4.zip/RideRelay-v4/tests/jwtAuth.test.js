const assert = require('assert');
const { generateJWT, verifyJWT } = require('../server.js');

function testJWTAuth() {
  console.log('--- TEST 3: JWT Bearer Token Security ---');

  const payload = { userId: 'USER-1', email: 'test@campus.edu', role: 'Student' };
  const token = generateJWT(payload);
  assert.ok(typeof token === 'string' && token.split('.').length === 3, 'Valid JWT structure');

  const decoded = verifyJWT(token);
  assert.strictEqual(decoded.email, 'test@campus.edu', 'Decoded email matches');
  assert.strictEqual(decoded.role, 'Student', 'Decoded role matches');

  // Tampered token test
  const tamperedToken = token + 'tampered';
  const invalidDecoded = verifyJWT(tamperedToken);
  assert.strictEqual(invalidDecoded, null, 'Tampered token should return null');

  console.log('✓ JWT Bearer Token Security Test Passed');
}

module.exports = testJWTAuth;
