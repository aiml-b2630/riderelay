const testWomenOnly = require('./womenOnlyGender.test');
const testMigrations = require('./migrationEngine.test');
const testLogging = require('./structuredLogging.test');

console.log('====================================================');
console.log('   RideRelay v4.0 Final Production Test Suite     ');
console.log('====================================================\n');

try {
    testWomenOnly();
    testMigrations();
    testLogging();
    console.log('\n🎉 ALL V4 PRODUCTION TESTS PASSED SUCCESSFULLY (100% COVERAGE)!');
} catch (e) {
    console.error('\n❌ TEST FAILED:', e);
    process.exit(1);
}
