/**
 * OpenAPI 3.0 Documentation Schema Specification
 */
const openapiSpec = {
    openapi: "3.0.0",
    info: {
        title: "RideRelay Campus Carpool API",
        version: "3.0.0",
        description: "Production REST API for campus carpooling, Haversine route matching, JWT auth, and women-only verification."
    },
    paths: {
        "/api/verify-email": {
            post: {
                summary: "Verify campus email domain & issue JWT",
                requestBody: {
                    required: true,
                    content: {
                        "application/json": {
                            schema: {
                                type: "object",
                                properties: {
                                    email: { type: "string", example: "student@campus.edu" },
                                    name: { type: "string", example: "Ananya Sharma" },
                                    gender: { type: "string", example: "female" }
                                }
                            }
                        }
                    }
                },
                responses: {
                    "200": { description: "Email verified & token issued" },
                    "400": { description: "Invalid campus email domain" }
                }
            }
        },
        "/api/rides": {
            get: {
                summary: "Fetch active rides feed",
                responses: { "200": { description: "List of active campus rides" } }
            },
            post: {
                summary: "Offer a new campus ride",
                security: [{ bearerAuth: [] }],
                responses: { "201": { description: "Ride created" } }
            }
        },
        "/api/book": {
            post: {
                summary: "Book seats on a ride with women-only gender enforcement",
                security: [{ bearerAuth: [] }],
                responses: {
                    "200": { description: "Booking confirmed & Ride Pass generated" },
                    "403": { description: "Gender restriction violation (Women-Only ride)" },
                    "409": { description: "Concurrency conflict / insufficient seats" }
                }
            }
        },
        "/api/rides/live": {
            get: {
                summary: "Server-Sent Events (SSE) stream for live ride updates",
                responses: { "200": { description: "Event stream (text/event-stream)" } }
            }
        }
    }
};

function renderSwaggerUI() {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>RideRelay API Docs</title>
    <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5.9.0/swagger-ui.css">
    <style>body { margin: 0; padding: 0; background: #0f172a; } .swagger-ui { filter: invert(88%) hue-rotate(180deg); }</style>
</head>
<body>
    <div id="swagger-ui"></div>
    <script src="https://unpkg.com/swagger-ui-dist@5.9.0/swagger-ui-bundle.js"></script>
    <script>
        window.onload = () => {
            SwaggerUIBundle({
                url: '/api/docs/openapi.json',
                dom_id: '#swagger-ui',
            });
        };
    </script>
</body>
</html>`;
}

module.exports = { openapiSpec, renderSwaggerUI };
