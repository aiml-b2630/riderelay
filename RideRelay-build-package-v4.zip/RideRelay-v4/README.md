# RideRelay v4.0 - Campus Carpool & Peer Ride-Sharing Platform

## Executive Summary
RideRelay v4.0 is a production-grade campus carpooling web application designed specifically for university students and faculty. It enables secure peer-to-peer commuting, fair fuel cost splitting, geospatial route matching, women-only safety filters, and instant digital ride pass generation.

---

## 🌟 Key Architecture & Technical Highlights

1. **Embedded SQLite Database (`node:sqlite`) & Migration Engine (`db/migrations.js`)**
   - Versioned migration tracking table (`schema_migrations`) executing idempotent schema updates.
   - Atomic database transactions preventing seat over-booking concurrency race conditions.

2. **Women-Only Safety Verification & Gender Restrictions**
   - Server-enforced passenger gender checks on `/api/book` for rides marked `is_women_only`.
   - Returns `403 GENDER_RESTRICTION_VIOLATION` if a non-female profile attempts booking a restricted ride.

3. **Haversine Geographic Proximity Route Matcher (`js/matching.js`)**
   - Computes exact spherical kilometer distances between passenger pickup `(lat, lng)` coordinates and driver route waypoints within configurable proximity radiuses.

4. **JWT Security & Environment Variable Secret Guard**
   - Strictly enforces JWT authentication for ride creation and seat bookings.
   - Dynamically initializes a secure 32-byte random runtime secret if `JWT_SECRET` is omitted.

5. **Server-Sent Events (SSE) Real-Time Broadcast Engine**
   - Native HTTP event streaming endpoint (`GET /api/rides/live`) broadcasting instant `SEAT_BOOKED` and `NEW_RIDE` events across connected clients.

6. **Structured Production Logging (`logger.js`) & OpenAPI 3.0 Specs (`/api/docs`)**
   - ISO-timestamped JSON logs with log levels and request IDs.
   - Built-in Swagger UI documentation endpoint at `/api/docs`.

7. **Offline PWA Resilience (`sw.js` & `js/offline.js`)**
   - Service Worker caching with LocalStorage fallback feed rendering during network dropouts.

---

## 🚀 Getting Started & Execution

### 1. Start Server
```bash
npm start
```
*Server starts on `http://localhost:3000` with API docs available at `http://localhost:3000/api/docs`.*

### 2. Run Automated Integration Test Suite
```bash
npm test
```

---

## 📂 Project Structure
```
RideRelay-v4/
├── server.js               # Express-free HTTP server with SQLite, JWT & SSE
├── logger.js               # Structured JSON logger
├── sw.js                   # Service Worker for offline PWA caching
├── index.html              # Main Responsive HTML5 Interface
├── package.json            # Project manifest & npm scripts
├── README.md               # Documentation & Setup Guide
├── db/
│   └── migrations.js       # Versioned SQLite database migration strategy
├── swagger/
│   └── openapi.js          # OpenAPI 3.0 specification & Swagger UI renderer
├── css/
│   └── styles.css          # Flexbox glassmorphism responsive styling
├── js/
│   ├── app.js              # Application controller & SSE listener
│   ├── api.js              # Fetch client with JWT header injection & SSE
│   ├── matching.js         # Haversine distance heuristic module
│   ├── ratings.js          # Campus Trust & Safety Rating Studio
│   ├── ui.js               # Toast notifications & ride pass rendering
│   ├── offline.js          # Offline resilience & local cache manager
│   └── types.ts            # TypeScript data interfaces
└── tests/
    ├── runAllTests.js      # Automated master test runner
    ├── womenOnlyGender.test.js
    ├── migrationEngine.test.js
    └── structuredLogging.test.js
```
